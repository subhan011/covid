<p align="center">
<img src="https://lh3.googleusercontent.com/-grjTcOMyemYN_JiN3QlkZzgh61D88LNFLj2-8QaqcjLWn_MouQe9zux8ZfMH4R7SLfR-cfHYD1b84KUlPqYucP5gZWTuo2J=s2560" width="100%">
</p>

<p align="center">
  View our live <a href="http://patientdb.covid19india.org/">database</a>.
 </p>

## Setup

```
npm i && npm start
```

## Maintainers

- [jeremyphilemon](https://github.com/jeremyphilemon)
- [shuklaayush](https://github.com/shuklaayush)
- [JunaidBabu](https://github.com/JunaidBabu)
- [sudevschiz](https://github.com/sudevschiz)

## Contribution

If you're new to contributing to Open Source on Github, [this guide](https://guides.github.com/activities/contributing-to-open-source/) can help you get started. Please check out the [contribution guide](CONTRIBUTING.md) for more details on how issues and pull requests work.

###### This repository is just a small subset of work put together by a much larger pool of voluntary efforts contributed by generous people all around the world. Reach out to us through hello@covid19india.org
